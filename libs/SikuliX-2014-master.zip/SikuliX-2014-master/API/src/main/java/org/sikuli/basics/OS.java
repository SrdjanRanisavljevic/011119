/*
 * Copyright 2010-2014, Sikuli.org, sikulix.com
 * Released under the MIT License.
 *
 * modified RaiMan 2013
 */
package org.sikuli.basics;

/**
 * @deprecated use Settings.isWindows(), ...isMac() or ...isLinux() instead
 */
@Deprecated
public enum OS {
   MAC, WINDOWS, LINUX,
   NOT_SUPPORTED
}
