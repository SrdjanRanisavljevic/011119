package org.sikuli.remoteinterfaces.entities;

/**
 * Author: Sergey Kuts
 */
public interface Image {

    String getPath();

    float getSimilarity();
}

