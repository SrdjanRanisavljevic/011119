/*
 * Copyright 2010-2014, Sikuli.org, sikulix.com
 * Released under the MIT License.
 *
 * modified RaiMan
 */

package org.sikuli.script;

/**
 * CANDIDATE FOR DEPRECATION - ONLY HERE TO BE BACKWARD COMPATIBLE
 */
public class SikuliEvent extends ObserveEvent {

}
