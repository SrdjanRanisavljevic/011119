/*
 * Copyright 2010-2014, Sikuli.org, sikulix.com
 * Released under the MIT License.
 *
 * modified RaiMan
 */
package org.sikuli.script;

/**
 * INTERNAL USE
 */
public enum FindFailedResponse{
   ABORT,
   PROMPT,
   SKIP,
   RETRY
};
