package org.sikuli.guide;

public interface GlobalMouseMotionListener {
   public void globalMouseMoved(int x, int y);
   public void globalMouseIdled(int x, int y);
}
